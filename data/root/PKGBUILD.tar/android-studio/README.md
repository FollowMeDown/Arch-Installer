# Android Studio for Arch Linux

This is a AUR package for Arch Linux packaging the [official releases](https://developer.android.com/studio#downloads) as convience and integrating with any AUR compatible package manager. Find all the details [aur.archlinux.org/packages/android-studio/](https://aur.archlinux.org/packages/android-studio/).

The [Github Repo](https://github.com/kordianbruck/arch-aur-android-studio) is [a mirror of the official repo](https://aur.archlinux.org/cgit/aur.git/log/?h=android-studio), but enables anyone to send pull reuqests.
