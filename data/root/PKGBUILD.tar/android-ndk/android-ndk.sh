export PATH="$PATH:/opt/android-ndk"
export ANDROID_NDK=/opt/android-ndk
# Some programs such as gradle ask this as well:
export ANDROID_NDK_HOME=/opt/android-ndk
